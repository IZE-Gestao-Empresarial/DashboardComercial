from __future__ import annotations


def pretty_name(name_upper: str) -> str:
    """Recebe nome em UPPER (como vem do DF) e devolve um formato agradável."""
    s = (name_upper or "").strip().title()
    s = s.replace("SDR", "SDR").replace("Sdr", "SDR").replace("Closer", "CLOSER")
    return s
PHOTO_FILES: dict[str, str] = {
    #"NURY": "assets/photos/nury.png",
    #"GUILHERME": "assets/photos/guilherme.png",
    #"MARIA EDUARDA": "assets/photos/maria.png",
    # Algumas fontes podem vir sem acento (JOAO) — deixamos os 2
    #"JOÃO": "assets/photos/joao.png",
    #"JOAO": "assets/photos/joao.png",
}
PHOTO_URLS: dict[str, str] = {
    "NURY": "https://i.imgur.com/KPbuDpB.png",
    "MARIA": "https://i.imgur.com/mxT5m7g.png",
    "JOÃO": "https://i.imgur.com/wl4sktg.png",
    "JOAO": "https://i.imgur.com/wl4sktg.png",
    "VICTOR": "https://i.imgur.com/oL93SKm.png",
    "LAURA": "https://i.imgur.com/oD23A9c.png",
    "CODRI": "https://i.imgur.com/fakgDcL.png",
    "MATHEUS": "https://i.imgur.com/uKjvrb1.png"
}